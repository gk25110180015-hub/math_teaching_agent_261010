"""Actual browser clicks against separate local server and worker processes.

These are MOCK provider tests. A successful test does not imply real API,
Windows TeX, mathematics, or teacher visual acceptance.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

import pytest

expect = pytest.importorskip("playwright.sync_api").expect

pytestmark = pytest.mark.e2e
PROJECT = Path(__file__).resolve().parents[2]


def browser_executable() -> str | None:
    override = os.environ.get("MATH_AGENT_BROWSER_PATH")
    candidates = [
        override,
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    ]
    return next((p for p in candidates if p and Path(p).is_file()), None)


@pytest.fixture(scope="module")
def local_services(tmp_path_factory):
    evidence = PROJECT / "reports" / "e2e" / time.strftime("%Y%m%d-%H%M%S")
    evidence.mkdir(parents=True, exist_ok=True)
    runtime = tmp_path_factory.mktemp("browser_runtime")
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("MATH_AGENT_"):
            env.pop(key)
    env.update({
        "MATH_AGENT_WORKSPACE": str(runtime / "workspace"),
        "MATH_AGENT_DATABASE_URL": "sqlite:///" + (runtime / "agent.db").as_posix(),
        "MATH_AGENT_REFERENCE_ROOT": str(PROJECT.parent),
        "MATH_AGENT_LIVE_API_ENABLED": "false",
        "MATH_AGENT_API_KEY": "",
        "MATH_AGENT_PORT": str(port),
        "PYTHONUNBUFFERED": "1",
    })
    processes = []
    logs = []
    try:
        for role, args in [
            ("server", ["serve", "--host", "127.0.0.1", "--port", str(port)]),
            ("worker", ["worker", "--concurrency", "1"]),
        ]:
            log = (evidence / f"{role}.log").open("w", encoding="utf-8")
            logs.append(log)
            processes.append(subprocess.Popen(
                [sys.executable, "-m", "math_agent.cli", *args],
                cwd=PROJECT, env=env, stdout=log, stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            ))
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if any(p.poll() is not None for p in processes):
                pytest.fail(f"Local service exited; preserved logs: {evidence}")
            try:
                with urllib.request.urlopen(base + "/api/health", timeout=1) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, TimeoutError):
                time.sleep(.2)
        else:
            pytest.fail(f"Server startup timed out; preserved logs: {evidence}")
        (evidence / "context.json").write_text(json.dumps({
            "base_url": base, "workspace": str(runtime), "provider": "mock",
            "teacher_visual_review": "NOT_RUN", "browser": browser_executable(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        yield base, evidence
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                if os.name == "nt":
                    taskkill = Path(os.environ["SystemRoot"]) / "System32" / "taskkill.exe"
                    subprocess.run([str(taskkill), "/PID", str(process.pid), "/T", "/F"], capture_output=True)
                else:
                    process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
        for log in logs:
            log.close()


@pytest.fixture
def browser_page(local_services, request):
    playwright = pytest.importorskip("playwright.sync_api")
    executable = browser_executable()
    with playwright.sync_playwright() as manager:
        try:
            browser = manager.chromium.launch(headless=True, executable_path=executable)
        except playwright.Error as error:
            pytest.skip(f"Browser unavailable: {str(error)[:300]}")
        context = browser.new_context(viewport={"width": 1440, "height": 1100}, locale="zh-CN")
        context.tracing.start(screenshots=True, snapshots=True, sources=True)
        page = context.new_page()
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(local_services[0])
        page.locator("#new-run-form").wait_for()
        yield page
        page.screenshot(path=str(local_services[1] / f"{request.node.name}.png"), full_page=True)
        context.tracing.stop(path=str(local_services[1] / f"{request.node.name}-trace.zip"))
        (local_services[1] / f"{request.node.name}-console.json").write_text(json.dumps(errors, ensure_ascii=False, indent=2), encoding="utf-8")
        browser.close()
        assert not errors, f"Browser JavaScript errors: {errors}"


def wait_for_plan(page):
    page.locator("#decisions-form").wait_for(timeout=60_000)


def submit_recommended(page):
    if page.locator("#use-recommended").count():
        page.locator("#use-recommended").click()
    page.locator("#save-decisions").click()
    expect(page.locator("#confirm-plan")).to_be_enabled()


def confirm_execute_refresh(page):
    page.locator("#confirm-plan").click()
    page.locator("#execute-plan").wait_for()
    page.reload()
    page.locator("#execute-plan").wait_for()
    assert page.locator("#confirm-plan").count() == 0
    page.locator("#execute-plan").click()
    expect(page.locator("[data-testid=run-status]")).not_to_have_attribute("data-status", "PLAN_CONFIRMED")
    page.reload()
    page.locator("#run-stage").wait_for()
    assert page.locator("#confirm-plan").count() == 0
    assert page.locator("#decisions-form").count() == 0


def test_lecture_real_clicks_restore_confirmation(browser_page):
    page = browser_page
    page.locator("#topic").fill("数列极限")
    page.locator("#difficulty").fill("经济学本科一年级微积分")
    assert not page.locator("#trusted-input").is_checked()
    page.locator("#trusted-input").check()
    page.locator("#create-run").click()
    wait_for_plan(page)
    assert page.locator("[data-question-id]").count() > 0
    for question in page.locator("[data-question-id]").all():
        assert question.locator(".choice input").last.get_attribute("value") == "CUSTOM"
        assert question.locator(".choice input:checked").count() == 0
    submit_recommended(page)
    page.get_by_text("本次计划变更（diff）", exact=True).wait_for()
    page.locator("#outline-editor > summary").click()
    page.locator("#outline-title").fill("数列极限 · 本科教学讲义")
    page.locator("#save-outline").click()
    page.get_by_role("heading", name="数列极限 · 本科教学讲义", exact=True).wait_for()
    confirm_execute_refresh(page)
    assert "MOCK" in page.locator("main").inner_text()


def test_beamer_exact_deletion_and_addition(browser_page, tmp_path):
    page = browser_page
    source = tmp_path / "中文 路径(样例).tex"
    source.write_text(r"""\documentclass{ctexart}
\usepackage{amsmath,amssymb,amsthm}
\newtheorem{definition}{定义}
\newtheorem{example}{例}
\begin{document}
\section{数列极限}
\begin{definition}若对任意 $\varepsilon>0$，存在 $N$，当 $n>N$ 时 $|a_n-a|<\varepsilon$，则称 $a_n$ 收敛于 $a$。\end{definition}
\begin{example}例 3：求 $\lim_{n\to\infty} 1/n$。\end{example}
\textbf{解：}由数列极限的定义，极限为 $0$。
\section{极限运算}
若 $a_n\to a$ 且 $b_n\to b$，则 $a_n+b_n\to a+b$。
\end{document}
""", encoding="utf-8")
    page.locator("#workflow").select_option("beamer.from_tex")
    assert page.locator("#theme option[value=fduclassroom]").count() == 1
    page.locator("#source-file").set_input_files(str(source))
    page.locator("#trusted-input").check()
    page.locator("#create-run").click()
    wait_for_plan(page)
    if page.locator("#use-recommended").count():
        page.locator("#use-recommended").click()
    page.get_by_text("删除或调整原讲义内容", exact=True).click()
    example = page.locator(".unit").filter(has_text="例 3").first
    example.locator("input[type=checkbox]").check()
    deleted_id = example.locator("input").get_attribute("value")
    page.get_by_text("添加原讲义之外的内容", exact=True).click()
    page.locator("#add-content").click()
    page.get_by_label("新增内容", exact=True).fill("补充例题：求常数数列的极限。")
    page.get_by_label("插入位置", exact=True).select_option("S01")
    page.locator("#save-decisions").click()
    expect(page.locator("#confirm-plan")).to_be_enabled()
    assert deleted_id in page.locator("main").inner_text()
    page.get_by_text("删除授权与依赖影响", exact=True).wait_for()
    assert "补充例题" in page.locator("main").inner_text()
    confirm_execute_refresh(page)


def test_custom_input_is_saved_as_plan_effect(browser_page):
    page = browser_page
    page.locator("#topic").fill("无穷级数")
    page.locator("#trusted-input").check()
    page.locator("#create-run").click()
    wait_for_plan(page)
    page.locator("#use-recommended").click()
    question = page.locator("[data-question-id]").first
    question.locator("input[value=CUSTOM]").check()
    custom_text = "关键定理提供完整证明，并明确全部先修条件。"
    question.locator("textarea").fill(custom_text)
    page.locator("#save-decisions").click()
    page.get_by_text("本次计划变更（diff）", exact=True).wait_for()
    expect(page.locator("main")).to_contain_text(custom_text)
    page.reload()
    page.get_by_text("本次计划变更（diff）", exact=True).wait_for()
    expect(page.locator("main")).to_contain_text(custom_text)


def test_compile_failure_retry_does_not_return_to_confirmation(browser_page, tmp_path):
    page = browser_page
    source = tmp_path / "失败恢复(合成).tex"
    source.write_text(r"""\documentclass{ctexart}
\usepackage{amsmath,amsthm}
\newtheorem{definition}{定义}
\begin{document}
\section{编译失败回归}
\begin{definition}数列是以正整数为定义域的函数。\end{definition}
\undefinedMathAgentFailure
\end{document}
""", encoding="utf-8")
    page.locator("#workflow").select_option("beamer.from_tex")
    page.locator("#source-file").set_input_files(str(source))
    page.locator("#trusted-input").check()
    page.locator("#create-run").click()
    wait_for_plan(page)
    submit_recommended(page)
    confirm_execute_refresh(page)
    page.locator("#retry-run").wait_for(timeout=120_000)
    assert page.locator("#confirm-plan").count() == 0
    assert page.locator(".error-panel").count() == 1
    page.reload()
    page.locator("#retry-run").wait_for()
    with page.expect_response(lambda response: response.url.endswith("/retry") and response.request.method == "POST") as retried:
        page.locator("#retry-run").click()
    assert retried.value.status == 202
    page.reload()
    page.locator("#run-stage").wait_for()
    assert page.locator("#confirm-plan").count() == 0
    assert page.locator("#decisions-form").count() == 0
